﻿using UnityEngine;
using System.Collections;
using System;
using UnityEngine.UI;

//Contains fields for UI display elements
//Contains the methods for modifying those fields
public class UIDisplay : MonoBehaviour
{
    //PlayerController fields
    public Text t_PlayerHealth;

    //ItemController fields
    public Text t_SelectedSlot;
    public Text t_SelectedName;
    public Text t_ItemCount;

    //Inventory fields
    public Text t_ItemTotal;

    //GameManager fields
    public Text t_HasBeenSpotted;

    //Game Log Field
    public Text t_Log;

    public static UIDisplay instance;

    void Awake()
    {
        if (instance != null)
        {
            Destroy(gameObject);
        }
        else
        {
            instance = this;
            DontDestroyOnLoad(gameObject);

            UpdateHasBeenSpotted(false);
        }
    }

    //PLAYERCONTROLLER//
    //Update Player Health
    public void UpdatePlayerHealth(int newPlayerHealth)
    {
        t_PlayerHealth.text = newPlayerHealth.ToString();
    }

    //ITEMCONTROLLER//
    //Update Selected Slot//
    public void UpdateSelectedSlot(int newItemSlot)
    {
        t_SelectedSlot.text = newItemSlot.ToString();
    }

    //Update Selected Name//
    public void UpdateSelectedName(string newItemName)
    {
        t_SelectedName.text = newItemName;
    }

    //Update Current Count
    public void UpdateItemCount(int newItemCount)
    {
        t_ItemCount.text = newItemCount.ToString();
    }

    //INVENTORY
    //Update Total Count
    public void UpdateItemTotal(int newItemCount)
    {
        t_ItemTotal.text = newItemCount.ToString();
    }

    //GAME MANAGER
    //Update player has been spotted
    public void UpdateHasBeenSpotted(bool beenSpotted)
    {
        t_HasBeenSpotted.text = beenSpotted.ToString();
    }

    //GENERAL LOG
    //Update Text Log
    public void UpdateLog(string newLogString)
    {
        t_Log.text = newLogString;
    }
}
