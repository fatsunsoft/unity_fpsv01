﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class MainMenu : MonoBehaviour
{
    public GameObject titleMenuHolder;
    public GameObject optionsMenuHolder;

    void Start()
    {
        TitleMenu();
    }

    public void TitleMenu()
    {
        titleMenuHolder.SetActive(true);
        optionsMenuHolder.SetActive(false);
    }

    public void OptionsMenu()
    {
        titleMenuHolder.SetActive(false);
        optionsMenuHolder.SetActive(true);
    }

    public void Play()
    {
        SceneManager.LoadScene(1);
    }

    public void Quit()
    {
        Application.Quit();
    }

    public void SetMasterVolume(float volume)
    {

    }

    public void SetEffectsVolume(float volume)
    {

    }

    public void SetAmbientVolume(float value)
    {

    }
}
