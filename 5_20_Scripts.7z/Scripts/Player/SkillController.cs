﻿using UnityEngine;
using System.Collections;

public class SkillController : MonoBehaviour
{
    public float XP;
    public int Level;

    void UpdateXPCount(float xpToAdd)
    {

    }

    void UpdateLevelCount(int levelToReach)
    {

    }
}
