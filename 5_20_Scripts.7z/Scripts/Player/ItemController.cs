﻿using UnityEngine;
using System.Collections;

//Control the Player interacting with their inventory of items
public class ItemController : MonoBehaviour
{
    public Transform itemHold;
    public Transform flashlightHold;

    public Item[] Items;
    public Key[] Keys;

    public int playerCurrency;

    private Light flashlight;
    private Item equippedItem;
    private bool toggleFlashlight;

    void Start()
    {
        //Get Flashlight
        flashlight = flashlightHold.GetComponent<Light>();

        for (int i = 0; i < Items.Length; i++)
        {
            CreateItem(i);
            Items[i] = equippedItem;            
        }
        EquipItem(0);
        ToggleFlashlight();
    }

    //Create Inventory Items
    public void CreateItem(int itemIndex)
    {
        CreateItem(Items[itemIndex]);
    }
    
    public void CreateItem(Item itemToCreate)
    {
        equippedItem = Instantiate(itemToCreate, itemHold.position, itemHold.rotation) as Item;
        equippedItem.transform.parent = itemHold;
        equippedItem.gameObject.SetActive(false);
    }

    //Equip Inventory Items
    public void EquipItem(int itemIndex)
    {
        if (Items[itemIndex].hasItem)
        {
            if(Items[itemIndex] != equippedItem)
            {
                EquipItem(Items[itemIndex]);
                UIDisplay.instance.UpdateSelectedSlot(itemIndex);
                UIDisplay.instance.UpdateLog("Equipped slot " + itemIndex);
            }
            else
            {
                UIDisplay.instance.UpdateLog("Item in slot " + itemIndex + " already equipped");
            }            
        }
        else
        {
            UIDisplay.instance.UpdateLog("Nothing in Slot");
        }        
    }
    
    public void EquipItem(Item itemToEquip)
    {
        equippedItem.gameObject.SetActive(false);
        equippedItem = itemToEquip;
        equippedItem.gameObject.SetActive(true);

        UIDisplay.instance.UpdateSelectedName(equippedItem.itemName);
        UIDisplay.instance.UpdateItemTotal(equippedItem.AmmoToUse());
        equippedItem.OnEquip();
    }


    //Trigger Hold
    public void OnTriggerHold()
    {
        if (equippedItem != null)
        {
            equippedItem.OnTriggerHold();
        }
    }

    //Trigger Release
    public void OnTriggerRelease()
    {
        if (equippedItem != null)
        {
            equippedItem.OnTriggerRelease();
        }
    }

    //Weapon Reload
    public void Reload()
    {
        equippedItem.Reload();
    }    

    //Flashlight Toggle
    public void ToggleFlashlight()
    {
        if (flashlight != null)
        {
            flashlight.enabled = toggleFlashlight;
            toggleFlashlight = !toggleFlashlight;
        }
    }
}

