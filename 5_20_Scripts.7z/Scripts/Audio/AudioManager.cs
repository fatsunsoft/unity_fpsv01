﻿using UnityEngine;
using System.Collections;

public class AudioManager : MonoBehaviour
{
    public enum AudioChannel { Master, Sfx, Ambient };

    AudioSource sfx2DSource;
    //AudioSource[] ambientSources;
    //int activeAmbientSourceIndex;

    public static AudioManager instance;

    //Transform audioListener;

    SoundLibrary library;

    void Awake()
    {
        if (instance != null)
        {
            Destroy(gameObject);
        }
        else
        {
            //assign the audiomanager instance
            instance = this;
            DontDestroyOnLoad(gameObject);

            //get our component sound library
            library = GetComponent<SoundLibrary>();

            //create an ambient source array, for loop for assignment
            /*
            ambientSources = new AudioSource[2];
            for (int i = 0; i < 2; i++)
            {
                GameObject newAmbientSource = new GameObject("Ambient source " + (i + 1));

                //create new ambient sound array source Component
                ambientSources[i] = newAmbientSource.AddComponent<AudioSource>();
                newAmbientSource.transform.parent = transform;
            }
            */

            GameObject newSfx2DSource = new GameObject("2D sfx source");

            //create new sfx2d source Component at the Audio Manager
            sfx2DSource = newSfx2DSource.AddComponent<AudioSource>();
            newSfx2DSource.transform.parent = transform;

            //assign the audio listener, should only exist on player
            //audioListener = FindObjectOfType<AudioListener>().transform;
        }
    }

    void Update()
    {
    }

    //Play ambient clip
    /*
    public void PlayAmbient(AudioClip ambientClip, float fadeDuration = 1)
    {
        activeAmbientSourceIndex = 1 - activeAmbientSourceIndex;
        ambientSources[activeAmbientSourceIndex].clip = ambientClip;
        ambientSources[activeAmbientSourceIndex].Play();

        StartCoroutine(AmbientCrossFade(fadeDuration));
    }
    */

    //play an audio clip at an audio source
    public void PlaySound(AudioClip clip, Vector3 pos)
    {
        if (clip != null)
        {
            AudioSource.PlayClipAtPoint(clip, pos);
        }
    }

    //call to play clip at source position
    public void PlaySound(string soundName, int soundID, Vector3 pos)
    {
        PlaySound(library.GetClip(soundName, soundID), pos);
    }

    //play a flat 2D sound like a gunshot originating at the player
    public void PlaySound2D(string soundName, int soundID)
    {
        sfx2DSource.PlayOneShot(library.GetClip(soundName, soundID));
    }

    /*
    IEnumerator AmbientCrossFade(float duration)
    {
        float percent = 0;

        while (percent < 1)
        {
            percent += Time.deltaTime * 1 / duration;
            ambientSources[activeAmbientSourceIndex].volume = Mathf.Lerp(0, 1, percent);
            ambientSources[1 - activeAmbientSourceIndex].volume = Mathf.Lerp(1, 0, percent);
            yield return null;
        }
    }
    */
}
