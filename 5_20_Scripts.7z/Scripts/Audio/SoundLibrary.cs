﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SoundLibrary : MonoBehaviour
{
    //inspector field for our sounds
    public SoundGroup[] SoundGroups;

    //create a new dictionary
    Dictionary<string, AudioClip[]> audioDictionary = new Dictionary<string, AudioClip[]>();

    void Awake()
    {
        //for each member soundgroup in our soundgroups array
        foreach (SoundGroup soundGroup in SoundGroups)
        {
            //add the soundgroup ID and audio to the dictionary
            audioDictionary.Add(soundGroup.groupID, soundGroup.group);
        }
    }

    //recall an audio clip from the dictionary
    public AudioClip GetClip(string name, int sound)
    {
        //if we find the group ID
        if (audioDictionary.ContainsKey(name))
        {
            //create an audioclip array
            AudioClip[] sounds = audioDictionary[name];

            //return sound
            return sounds[sound];
        }
        //if no key
        return null;
    }

    //this class contains an ID and an audioclip array
    [System.Serializable]
    public class SoundGroup
    {
        public string groupID;
        public AudioClip[] group;
    }
}
