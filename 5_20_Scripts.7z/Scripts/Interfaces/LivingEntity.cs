﻿using UnityEngine;

//Base class for Player and enemies
public class LivingEntity : MonoBehaviour, IDamageable
{
    public int startingHealth;
    protected int health;
    protected bool dead;

    //variable event which can be broadcast as OnDeath
    public event System.Action OnDeath;

    //assign health
    protected virtual void Start()
    {
        health = startingHealth;
    }

    //When the Object takes a Hit
    public virtual void TakeHit(int damage, Vector3 hitPoint, Vector3 hitDirection)
    {
        TakeDamage(damage);
    }

    //Get Damaged
    public virtual void TakeDamage(int damage)
    {
        health -= damage;

        //if health 0 or less, die
        if (health <= 0 && !dead)
        {
            Die();
        }
    }

    //Destroy on Death
    protected void Die()
    {
        dead = true;

        //invoke event OnDeath
        if (OnDeath != null)
        {
            Debug.Log("Living entity ondeath event");
            OnDeath();

        }
        GameObject.Destroy(gameObject);
    }
}

