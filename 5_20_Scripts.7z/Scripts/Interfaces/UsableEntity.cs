﻿using UnityEngine;

//Base class for usable objects
public class UsableEntity : MonoBehaviour, IUsable
{
    public enum UsableType { Lock, Key, Item, Ammo };
    public UsableType usableType;

    public bool IsLocked;
    public bool IsPickable;
    public int keyIndex;

    public int itemIndex;
    public int ammoCount;

    protected bool IsUsed;

    //variable event which can be broadcast as OnUse
    public event System.Action OnUse;

    protected virtual void Start()
    {
        if (usableType != UsableType.Lock)
        {
            IsLocked = false;
            IsPickable = false;
        }
    }

    //Use with 'E' Hit Pickup Key
    public virtual bool TakeUseHit(Vector3 hitPoint, Vector3 hitDirection, Key[] keyRing)
    {
        if (usableType == UsableType.Lock)
        {
            if (IsLocked && keyRing[keyIndex].isAcquired)
            {
                IsLocked = false;
                UIDisplay.instance.UpdateLog("Unlocked the Object with Key " + keyIndex);
                gameObject.SetActive(false);
            }
            else if (IsLocked && !keyRing[keyIndex].isAcquired)
            {
                UIDisplay.instance.UpdateLog("Requires Key " + keyIndex + " to Unlock");
            }
            return true;
        }
        else if (usableType == UsableType.Key)
        {          
            keyRing[keyIndex].isAcquired = true;
            UIDisplay.instance.UpdateLog("Key Picked Up");
            gameObject.SetActive(false);
            return true;
        }
        else
        {
            return false;
        }
    }
    //Use with 'E' Hit Pickup Item
    public virtual void TakeUseHit(Vector3 hitPoint, Vector3 hitDirection, Item[] allItems)
    {
        if (usableType == UsableType.Item && !allItems[itemIndex].hasItem)
        {
            allItems[itemIndex].hasItem = true;
            UIDisplay.instance.UpdateLog("Acquired the Item");
        }
        else if (usableType == UsableType.Ammo)
        {
            allItems[itemIndex].AmmoToUse(-ammoCount);
            UIDisplay.instance.UpdateLog("Acquired " + ammoCount + " ammo for weapon at " + itemIndex);
        }
        else
        {
            UIDisplay.instance.UpdateLog("Already have the Item");
        }
    }

    //Lockpick Hit
    public virtual void TakeUseHit(Vector3 hitPoint, Vector3 hitDirection, Item.ItemType itemType)
    {
        if (IsLocked && IsPickable && itemType == Item.ItemType.Tool)
        {
            IsLocked = false;
            UIDisplay.instance.UpdateLog("Unlocked the Object");
            gameObject.SetActive(false);
        }
        else if (IsLocked && !IsPickable && itemType == Item.ItemType.Tool)
        {
            UIDisplay.instance.UpdateLog("Lock is not Pickable");
        }
        else if (IsLocked && itemType != Item.ItemType.Tool)
        {
            UIDisplay.instance.UpdateLog("Object is Locked");
        }
        else
        {
            UIDisplay.instance.UpdateLog("Object not locked");
        }
        ChangeState();
    }

    protected void ChangeState()
    {
        IsUsed = !IsUsed;

        if (OnUse != null)
        {
            Debug.Log("Usable Entity On Use Event");
            OnUse();
        }
    }
}
