﻿using UnityEngine;

public interface IUsable
{
    void TakeUseHit(Vector3 hitPoint, Vector3 hitDirection, Item.ItemType itemType);

    bool TakeUseHit(Vector3 hitPoint, Vector3 hitDirection, Key[] keyRing);

    void TakeUseHit(Vector3 hitPoint, Vector3 hitDirection, Item[] allItems);
}
