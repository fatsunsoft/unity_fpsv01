﻿using UnityEngine;

public class LaserDetection : MonoBehaviour
{
    private GameObject player;
    private PlayerSighting lastPlayerSighting;

    void Awake()
    {
        player = GameObject.FindGameObjectWithTag("Player");
        lastPlayerSighting = GameObject.FindGameObjectWithTag("GameController").GetComponent<PlayerSighting>();
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject == player)
        {
            lastPlayerSighting.position = other.transform.position;
        }
    }
}
