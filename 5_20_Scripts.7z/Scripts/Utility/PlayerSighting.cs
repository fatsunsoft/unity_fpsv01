﻿using UnityEngine;

//Global sighting and alarm
public class PlayerSighting : MonoBehaviour
{
    public Vector3 position = new Vector3(0f, -10f, 0f);
    public Vector3 resetPosition = new Vector3(0f, -10f, 0f);

    private AlarmLight alarmLight;

    private float onDuration = 5f;
    private float timer = 0f;

    void Awake()
    {
        //refernece alarm light and audio
        alarmLight = GameObject.FindGameObjectWithTag("Alarm").GetComponent<AlarmLight>();
    }

    void FixedUpdate()
    {
        SwitchAlarms();

        if (alarmLight.alarmOn)
        {
            timer += Time.deltaTime;

            if (timer >= onDuration)
            {
                position = resetPosition;

                timer = 0f;
            }
        }
    }

    void SwitchAlarms()
    {
        //if last global sighting is not default position, alarm on
        alarmLight.alarmOn = position != resetPosition;
    }
}
