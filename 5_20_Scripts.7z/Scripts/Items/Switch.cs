﻿using UnityEngine;

//Switches the attached gameobjects between two states
public class Switch : UsableEntity
{
    public GameObject[] switchObjects;
    public bool startUsed;

    //public static event System.Action OnUseStatic;

    private bool isSwitched = false;

    void Awake()
    {
        if (startUsed)
        {
            for (int i = 0; i < switchObjects.Length; i++)
            {
                switchObjects[i].SetActive(isSwitched);
            }
        }
        isSwitched = startUsed;
    }

    protected override void Start()
    {
        base.Start();
    }

    public override void TakeUseHit(Vector3 hitPoint, Vector3 hitDirection, Item.ItemType itemType)
    {
        base.TakeUseHit(hitPoint, hitDirection, itemType);
        if (!base.IsLocked)
        {
            for (int i = 0; i < switchObjects.Length; i++)
            {
                switchObjects[i].SetActive(isSwitched);
            }
            isSwitched = !isSwitched;
        }
    }
}
