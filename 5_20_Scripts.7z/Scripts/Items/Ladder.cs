﻿using UnityEngine;

public class Ladder : MonoBehaviour
{
    void OnTriggerEnter(Collider c)
    {
        c.GetComponent<Player>().m_OnLadder = true;
        Debug.Log("Touching Ladder");
    }

    void OnTriggerExit(Collider c)
    {
        c.GetComponent<Player>().m_OnLadder = false;
        Debug.Log("No Longer Touching Ladder");
    }
}
