﻿using System;

[Serializable]
public class Key
{
    public enum KeyType { Key_0, Key_1, Key_2 };
    public KeyType keyType;

    public bool isAcquired;
}
