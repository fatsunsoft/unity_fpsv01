﻿using UnityEngine;
using System.Collections;

//Class for instances of Items
public class Item : MonoBehaviour
{
    //What type of Item
    public enum ItemType { Weapon, Tool };
    public ItemType itemType;

    //Ammo if Any
    public enum AmmoType { Pistol, Revolver, Rifle, Shotgun, none};
    public AmmoType ammoType;

    //Static for Shared Ammo
    [HideInInspector]
    public static int PistolAmmo;
    [HideInInspector]
    public static int RevolverAmmo;
    [HideInInspector]
    public static int RifleAmmo;
    [HideInInspector]
    public static int ShotgunAmmo;
    [HideInInspector]
    public int ammoInClip;

    //Name for the Item
    public string itemName;

    public int damage;
    public int clipCap;
    public float msUseDelay;
    public float range;

    //Control if We have the item
    public bool hasItem;

    //Audio Index
    public int audioIndex;   

    private bool triggerReleased;
    private float lastUseTime;

    private Camera playerCamera;

    void Awake()
    {
        PistolAmmo = 64;
        RevolverAmmo = 18;
        RifleAmmo = 32;
        ShotgunAmmo = 24;

        playerCamera = Camera.main;

        ammoInClip = clipCap;
        triggerReleased = true;

        msUseDelay /= 1000;

        lastUseTime = Time.time;
    }

    public void Use()
    {
        if (!triggerReleased)
        {
            return;
        }
        else
        {
            RaycastHit hit;
            if (Physics.Raycast(playerCamera.transform.position, playerCamera.transform.forward, out hit, range))
            {
                //Get IDamageable if Wielding Weapon
                if (itemType == ItemType.Weapon)
                {
                    OnHitObject(hit.collider, hit.point);
                    AudioManager.instance.PlaySound2D("Gunshot", audioIndex);
                }
                //Get IUsable if Wielding Tool or Key
                else if(itemType == ItemType.Tool)
                {
                    OnUseObject(hit.collider, hit.point);
                }
                
            }
            Debug.DrawRay(playerCamera.transform.position, playerCamera.transform.forward * 100f, Color.green, .1f);           

            //Use Delay
            lastUseTime = Time.time + msUseDelay;            
        }
    }


    //Hold the Trigger
    public void OnTriggerHold()
    {
        if(triggerReleased && lastUseTime < Time.time)
        {
            if (clipCap == 0)
            {
                Use();
            }

            else if (ammoInClip > 0)
            {
                Use();
                ammoInClip--;
                UIDisplay.instance.UpdateItemCount(ammoInClip);
            }
            triggerReleased = false;
        }        
    }
    
    //Release the Trigger
    public void OnTriggerRelease()
    {
        triggerReleased = true;
    }

    //Weapon Reload
    public void Reload()
    {        
        int ammoToUse = AmmoToUse();
        AudioManager.instance.PlaySound2D("Reload", audioIndex);
        if (ammoToUse + ammoInClip < clipCap)
        {
            ammoInClip += ammoToUse;
            AmmoToUse(ammoToUse);
            UIDisplay.instance.UpdateItemCount(ammoInClip);
        }
        else
        {
            int r = clipCap - ammoInClip;
            ammoInClip = clipCap;
            AmmoToUse(r);
            UIDisplay.instance.UpdateItemCount(ammoInClip);            
        }
    }

    //OnEquip
    public void OnEquip()
    {
        UIDisplay.instance.UpdateItemCount(ammoInClip);
        UIDisplay.instance.UpdateItemTotal(AmmoToUse());
    }

    //For Damagaeable Objects
    void OnHitObject(Collider c, Vector3 hitPoint)
    {
        IDamageable damageableObject = c.GetComponent<IDamageable>();

        if (damageableObject != null)
        {
            damageableObject.TakeHit(damage, hitPoint, transform.forward);
            Debug.Log("Damageable Entity");
        }
    }

    //For Usable Objects
    void OnUseObject(Collider c, Vector3 hitPoint)
    {
        IUsable usableObject = c.GetComponent<IUsable>();

        if (usableObject != null)
        {
            usableObject.TakeUseHit(hitPoint, transform.forward, itemType);
            Debug.Log("Usable Entity");
        }
    }

    public int AmmoToUse()
    {
        if (ammoType == AmmoType.Pistol)
        {
            return PistolAmmo;
        }
        else if (ammoType == AmmoType.Revolver)
        {
            return RevolverAmmo;
        }
        else if (ammoType == AmmoType.Rifle)
        {
            return RifleAmmo;
        }
        else if (ammoType == AmmoType.Shotgun)
        {
            return ShotgunAmmo;
        }
        else
        {
            return 0;
        }
    }
    public void AmmoToUse(int usedAmmo)
    {
        if (ammoType == AmmoType.Pistol)
        {
            PistolAmmo -= usedAmmo;
        }
        else if (ammoType == AmmoType.Revolver)
        {
            RevolverAmmo -= usedAmmo;
        }
        else if (ammoType == AmmoType.Rifle)
        {
            RifleAmmo -= usedAmmo;
        }
        else if (ammoType == AmmoType.Shotgun)
        {
            ShotgunAmmo -= usedAmmo;
        }
        UIDisplay.instance.UpdateItemTotal(AmmoToUse());
    }
}
